package com.myrncommu;

import android.content.Context;
import android.text.TextUtils;
import android.widget.Toast;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.facebook.react.uimanager.IllegalViewOperationException;

/**
 * Created by Administrator on 2016/9/22.
 */
 
public class MyNativeModule extends ReactContextBaseJavaModule {
 
  public static final String REACTCLASSNAME = "MyNativeModule";
  private Context mContext;
 
  public MyNativeModule(ReactApplicationContext reactContext) {
    super(reactContext);
    mContext = reactContext;
  }
 
  @Override
  public String getName() {
    return REACTCLASSNAME;
  }
 
  /**
   * 必须添加反射注解不然会报错
   * 这个方法就是ReactNative将要调用的方法，会通过此类名字调用
   * @param msg
   */
  @ReactMethod
  public void callNativeMethod(String msg) {
    Toast.makeText(mContext, msg, Toast.LENGTH_SHORT).show();

  }

  @ReactMethod
  public void tryCallBack(String name, String psw, Callback errorCallback, Callback successCallback){
    try{
      if(TextUtils.isEmpty(name) && TextUtils.isEmpty(psw)){
        // 失败时回调
        errorCallback.invoke("user or psw  is empty");
      }
      // 成功时回调
      successCallback.invoke("add user success");
      sendEvent((ReactContext)mContext, "Native Module", "ok");
     }catch(IllegalViewOperationException e){
        // 失败时回调
        errorCallback.invoke(e.getMessage());
      }
  }

  @ReactMethod
  public void tryPromise(String name, String psw, Promise promise){
    try{
      if(TextUtils.isEmpty(name) && TextUtils.isEmpty(psw)){
        promise.reject("0","user name  or psw is empty");
      }
      WritableMap map = Arguments.createMap();
      map.putString("user_id", "JS invoke JAVA success！");
      promise.resolve(map);
    }catch(IllegalViewOperationException e){
      promise.reject("2",e.getMessage());
    }
  }

  public  static void sendEvent(ReactContext reactContext, String eventName, String status)
  {
        System.out.println("reactContext="+reactContext);

        reactContext
                .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                .emit(eventName,status);
  }
}

