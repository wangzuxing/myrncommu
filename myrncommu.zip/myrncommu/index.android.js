/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Image,
  PanResponder,
  TouchableOpacity,
  DeviceEventEmitter,
  NativeModules
} from 'react-native';

class Mixture extends Component {
  render() {
    return (
      <View style={styles.container} >
        <Text style={styles.instructionson} onPress={() => this.onClick()}>
          native method
        </Text>
        <TouchableOpacity
          activeOpacity={0.5}    
          onPress={()=> this.onClick0()}> 
          <Image 
            source={require('./fruit0.png')} 
            style={{width: 70, height: 70}} 
          />
        </TouchableOpacity>
        <TouchableOpacity
          activeOpacity={0.5}    
          onPress={()=> this.onClick1()}> 
          <Image 
            source={require('./fruit1.png')} 
            style={{width: 70, height: 70}} 
          />
        </TouchableOpacity>
      </View>
    );
  }

  constructor(props) {
    super(props);
    this.state = {
       eventName:'',
       pos: '',
    };
    this.myPanResponder={}
  }
  componentWillMount() {
      this.myPanResponder = PanResponder.create({
      //Responder

      onStartShouldSetPanResponder: (evt, gestureState) => true,
      onStartShouldSetPanResponderCapture: (evt, gestureState) => true,
      onMoveShouldSetPanResponder: (evt, gestureState) => true,
      onMoveShouldSetPanResponderCapture: (evt, gestureState) => true,
      onPanResponderTerminationRequest: (evt, gestureState) => true,  
 
      //Responder handle:
      onPanResponderGrant: (evt, gestureState) => {
        this.state.eventName='start';
        this.forceUpdate();
        alert(this.state.eventName);
      },
      onPanResponderMove: (evt, gestureState) => {
        var _pos = 'x:' + gestureState.moveX + ',y:' + gestureState.moveY;
        this.setState( {eventName:'move',pos : _pos} );
      },
      onPanResponderRelease: (evt, gestureState) => {
        this.setState( {eventName:'up'} );
        alert(this.state.eventName);
      },
      onPanResponderTerminate: (evt, gestureState) => {
        this.setState( {eventName:'other new responser'} )
      },
    });
  }

  componentDidMount() {
    //add listener
    DeviceEventEmitter.addListener('Native Module',(message) => {
        alert('JS receive Native Module data ' + message);
    });
  } 

  onClick0() {
    NativeModules.MyNativeModule.tryCallBack("wangzuxing","35",(errorCallback)=>{
      alert(errorCallback)},(successCallback)=>{
        alert(successCallback);
      });
  }

  onClick1() {
    NativeModules.MyNativeModule.tryPromise('wang zux ing', '35').then((map)=> { 
    alert(map['user_id']);}, (code, message)=> {
        alert(message);
    });
  }

  //call Native Method
  onClick() {
    NativeModules.MyNativeModule.callNativeMethod('success invoke!');
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
    padding: 10,
    margin: 20,
    fontSize: 25
  },
});

AppRegistry.registerComponent('myrncommu', () => Mixture);
